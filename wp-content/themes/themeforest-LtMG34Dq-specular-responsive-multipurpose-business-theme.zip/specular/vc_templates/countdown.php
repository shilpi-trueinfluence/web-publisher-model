<?php

 /**
 * Shortcode attributes
 * @var $atts
 * @var $year
 * @var $month
 * @var $day
 * Shortcode class
 * @var $this WPBakeryShortCode_Countdown
 */
$output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
wp_enqueue_script('countdown', get_template_directory_uri(). '/js/jquery.countdown.min.js');
	
		$output = '<div class="wpb_content_element countdown">';

        

        $output .= '<div id="countdowndiv"></div>';

	 	$output .= "\n <script type='text/javascript'>\n /* <![CDATA[ */  \n";

    	$output .= 'jQuery(document).ready(function($){$("#countdowndiv").countdown({until: new Date('.esc_js($year).', '.esc_js(($month-1)).', '.esc_js($day).')})} );';

    	$output .= "</script>\n \n ";

 

         

        $output .= '</div>';

        echo codeless_complex_esc($output); 

?>