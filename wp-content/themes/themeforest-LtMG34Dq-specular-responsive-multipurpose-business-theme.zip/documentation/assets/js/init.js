!function ($) {
  $(function(){
	
	//$('.dropdown-toggle').dropdown()
	
	//$('.navbar').scrollspy()
	
	//$(".collapse").collapse()
	
	 
	
    // make code pretty
    window.prettyPrint && prettyPrint()
})
}(window.jQuery)



