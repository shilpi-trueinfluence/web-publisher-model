
<form action="<?php echo esc_url(home_url()) ?>" id="search-form">
                            <div class="input-append">
                                <input type="text" size="16" placeholder="<?php esc_attr_e('Search', 'specular') ?>&hellip;" name="s" id="s"><button type="submit" class="more"><?php esc_html_e('Search', 'specular') ?></button>
                            	<a href="#" class="close_"><i class="moon-close"></i></a>
                            </div>
</form>