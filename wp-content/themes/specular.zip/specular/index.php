<?php 

do_action('codeless_routing_template');

get_template_part( 'template', 'blog' );

?>